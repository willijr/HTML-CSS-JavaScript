var amounts = [["$200–299", 0],
               ["$300–399", 0],
               ["$400–499", 0],
               ["$500–599", 0],
               ["$600–699", 0],
               ["$700–799", 0],
               ["$800–899", 0],
               ["$900–999", 0],
               ["$1,000 and over", 0]];
var number = 1;
var sales;
var salary;

run();

function run()
{
   document.write( "<p>Please enter the gross amount of sales for the " );
   document.writeln( ordinal_suffix_of(number) + " employee: " );
   document.write( "<input type=\"text\" style=\"width: 60px\" " );
   document.writeln( "id=\"mySales\" autofocus=\"autofocus\">" );
   document.writeln( "<button onclick=\"calculateSalary()\">Submit</button>" );
   document.writeln( "<button onclick=\"clearTotals()\">Clear</button></p>" );
}

function calculateSalary()
{
   sales = parseInt(document.getElementById("mySales").value);
   document.body.innerHTML = "";
   salary = 200 + (sales * 0.09);
   if (salary >= 200 && salary < 300)
      amounts[0][1]++;
   else if (salary >= 300 && salary < 400)
      amounts[1][1]++;
   else if (salary >= 400 && salary < 500)
      amounts[2][1]++;
   else if (salary >= 500 && salary < 600)
      amounts[3][1]++;
   else if (salary >= 600 && salary < 700)
      amounts[4][1]++;
   else if (salary >= 700 && salary < 800)
      amounts[5][1]++;
   else if (salary >= 800 && salary < 900)
      amounts[6][1]++;
   else if (salary >= 900 && salary < 1000)
      amounts[7][1]++;
   else
      amounts[8][1]++;
   table();
}

function table()
{
   document.write( "<table border = \"3\"><caption>Salaries" );
   document.writeln( "</caption>" );
   document.write( "<thead><tr><th>Range</th><th>No. of Employees" );
   document.writeln( "</th></tr></thead><tbody>" );
   for (i = 0; i < amounts.length; i++)
   {
      document.write( "<tr><td align=\"center\">" + amounts[i][0]);
      document.write( "</td><td align=\"center\">" + amounts[i][1]);
      document.writeln( "</td></tr>" );
   }
   document.writeln( "</tbody></table><br />" );
   number++;
   run();
}

function clearTotals()
{
   for (i = 0; i < amounts.length; i++)
      amounts[i][1] = 0;
   number = 1;
   document.body.innerHTML = "";
   table();
}

function ordinal_suffix_of(i)
{
   var j = i % 10,
      k = i % 100;
   if (j == 1 && k != 11) {
      return i + "st";
   }
   if (j == 2 && k != 12) {
      return i + "nd";
   }
   if (j == 3 && k != 13) {
      return i + "rd";
   }
   return i + "th";
}