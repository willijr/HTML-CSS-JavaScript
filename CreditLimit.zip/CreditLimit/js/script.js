<!--

var accountNumber;
var acctNum;
var beginningBalance;
var beginBalance;
var totalCharged;
var totalCharges;
var totalCredited;
var totalCredits;
var totalAllowable;
var totalAllowed;
var newBalance;
var difference;

accountNumber = window.prompt( "Enter account number" );
beginningBalance = window.prompt( "Enter the balance at the beginning of the month" );
totalCharged = window.prompt( "Enter total of all items charged by this customer this month" );
totalCredited = window.prompt( "Enter total of all credits applied to this customer's account this month" );
totalAllowable = window.prompt( "Enter allowed credit limit" );

acctNum = parseInt( accountNumber );
beginBalance = parseInt( beginningBalance );
totalCharges = parseInt( totalCharged );
totalCredits = parseInt( totalCredited );
totalAllowed = parseInt( totalAllowable );

newBalance = beginBalance + totalCharges - totalCredits;

document.writeln( "<h1>Credit Limit Check</h1>" );
document.writeln( "<p>Account Number: " + acctNum + "</p>");
document.writeln( "<p>Beginning Balance: $" + beginBalance + "</p>");
document.writeln( "<p>New Charges: +$" + totalCharges + "</p>");
document.writeln( "<p>New Credits: -$" + totalCredits + "</p>");
document.writeln( "<p>End Balance: $" + newBalance + "</p>");

if (newBalance > totalAllowed)
{
    difference = newBalance - totalAllowed;
    document.writeln( "<p>End balance of $" + newBalance + " is greater than allowed credit of $"
            + totalAllowable + " by $" + difference + ".</p>");
    document.writeln( "<h3>Credit limit exceeded.</h3>" );
}

if (newBalance < totalAllowed)
{
    difference = totalAllowed - newBalance;
    document.writeln( "<p>End balance of $" + newBalance + " is less than allowed credit of $"
            + totalAllowable + ", with an available credit of $" + difference + ".</p>");
}
// -->