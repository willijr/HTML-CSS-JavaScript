var number;
var guess;
var count;

start();

function start()
{
   count = 0;
   number = Math.floor((Math.random() * 1000) + 1);
   document.writeln( "<p>Guess a number between 1 and 1000:" );
   document.writeln( "<input type=\"text\" style=\"width: 40px\" id=\"myText\" autofocus=\"autofocus\">" );
   document.writeln( "<button onclick=\"compare()\">Check Guess</button></p>" );
}

function compare()
{
   guess = document.getElementById("myText").value;

   if (guess == number)
   {
      count++;
      equals();
   } // end if

   else if (guess < number)
   {
      count++;
      less();
   } // end else if

   else if (guess > number)
   {
      count++;
      greater();
   } // end else if

   else
   {
      other();
   } // end else
}

function equals()
{
   document.body.innerHTML = "";
   document.writeln( "<h1>You guessed the number " + number + " in " + count + " guesses!</h1>" );

   if (count < 10)
   {
      document.writeln( "<h5>Either you know the secret or you got lucky!</h5>" );
      document.writeln( "<button onclick=\"newGame()\">Start Over</button>" );
   } // end if

   else if (count == 10)
   {
      document.writeln( "<h5>Ahah! You know the secret!</h5>" );
      document.writeln( "<button onclick=\"newGame()\">Start Over</button>" );
   } // end else if

   else
   {
      document.writeln( "<h5>You should be able to do better!</h5> ");
      document.writeln( "<button onclick=\"newGame()\">Start Over</button>" );
   } // end else
}

function less()
{
   document.body.innerHTML = "";
   document.writeln( "<p>" + guess + " is too low, try again:" );
   document.writeln( "<input type=\"text\" style=\"width: 40px\" id=\"myText\">" );
   document.writeln( "<button onclick=\"compare()\">Check Guess</button></p>" );
}

function greater()
{
   document.body.innerHTML = "";
   document.writeln( "<p>" + guess + " is too high, try again:" );
   document.writeln( "<input type=\"text\" style=\"width: 40px\" id=\"myText\">" );
   document.writeln( "<button onclick=\"compare()\">Check Guess</button></p>" );
}

function other()
{
   document.body.innerHTML = "";
   document.writeln( "That is not an accepatable value and does not count, try again:" );
}

function newGame()
{
   document.body.innerHTML = "";
   start();
}