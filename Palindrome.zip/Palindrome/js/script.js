var amountOfWords = 5;
var words = [];
for (var i = 0; i < amountOfWords; i++)
{
   words[i] = [];
}
var count = 0;

run();

function run()
{
   if (count < amountOfWords)
   {
      document.write( "<p>Please enter " + amountOfWords);
      document.write( " words to check if palindrome.<br />" );
      document.writeln( "Word " + (count + 1) + ":   " );
      document.write( "<input type=\"text\" style=\"width: 70px\" " );
      document.writeln( "id=\"myText\" autofocus=\"autofocus\">" );
      document.writeln( "<button onclick=\"add()\">Enter</button></p>" );
   }
   else
   {
      array("Is It a Palindrome");
   }
}

function add()
{
   words[count][0] = (document.getElementById("myText").value).toLowerCase();
   var x = palindrome(words[count][0]);
   if (x == true)
      words[count][1] = "Yes";
   else
      words[count][1] = "No";
   count++;
   document.body.innerHTML = "";
   run();
}

function array(heading)
{
   document.write( "<table border = \"3\"><caption>" + heading);
   document.writeln( "</caption>" );
   document.write( "<thead><tr><th>Your Word(s)</th><th>Palindrome?" );
   document.writeln( "</th></tr></thead><tbody>" );
   for (i = 0; i < words.length; i++)
   {
      document.write( "<tr><td align=\"center\">" + words[i][0]);
      document.write( "</td><td align=\"center\">" + words[i][1]);
      document.writeln( "</td></tr>" );
   }
   document.writeln( "</tbody></table><br />" );
}

function palindrome(str)
{
   var re = /[\W_]/g;
   var lowRegStr = str.toLowerCase().replace(re, "");
   var reverseStr = lowRegStr.split("").reverse().join("");
   if (reverseStr == lowRegStr)
      return true;
   else
      return false;
}