var numbers = [];
for (var i = 0; i < 5; i++)
{
   numbers[i] = [];
}
var count = 0;
var number = 1;

var amountOfNumbers = 5;

run();

function run()
{
   if (count < amountOfNumbers)
   {
      document.write( "<p>Please enter " + amountOfNumbers);
      document.write( " integers.<br />" );
      document.writeln( "Number " + number + ":  " );
      document.write( "<input type=\"text\" style=\"width: 30px\" " );
      document.writeln( "id=\"myText\" autofocus=\"autofocus\">" );
      document.writeln( "<button onclick=\"add()\">Enter</button></p>" );
   }
   else
   {
      array("Numbers Entered");
      numbers.sort(function(a, b){return b[0] - a[0]});
      array("Numbers Descending");
      numbers.reverse();
      array("Numbers Ascending");
   }
}

function add()
{
   numbers[count][0] = document.getElementById("myText").value;
   numbers[count][1] = ordinal_suffix_of(number);
   count++;
   number++;
   document.body.innerHTML = "";
   run();
}

function array(heading)
{
   document.write( "<table border = \"3\"><caption>" + heading);
   document.writeln( "</caption>" );
   document.write( "<thead><tr><th>Entered</th><th>Your number" );
   document.writeln( "</th></tr></thead><tbody>" );
   for (i = 0; i < numbers.length; i++)
   {
      document.write( "<tr><td align=\"center\">" + numbers[i][1]);
      document.write( "</td><td align=\"center\">" + numbers[i][0]);
      document.writeln( "</td></tr>" );
   }
   document.writeln( "</tbody></table><br />" );
}

function ordinal_suffix_of(i) {
   var j = i % 10,
      k = i % 100;
   if (j == 1 && k != 11) {
      return i + "st";
   }
   if (j == 2 && k != 12) {
      return i + "nd";
   }
   if (j == 3 && k != 13) {
      return i + "rd";
   }
   return i + "th";
}