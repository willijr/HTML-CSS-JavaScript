<!--

var countNum;
var total1 = 0;
var total2 = 0;
var total3 = 0;
var total4 = 0;
var total5 = 0;
var totalAmount = 0;
var productNumber;
var count;

productNumber = window.prompt( "Enter the product number, -1 to Quit:", "1" );

while ( productNumber != -1 )
{
	switch (productNumber)
	{
		case "1":
			countNum = window.prompt( "Enter the quantity of Product 1 sold this week", "0" );
			count = parseInt( countNum );
			total1 = total1 + ( 2.98 * count );
			totalAmount = totalAmount + total1;
			break;
		case "2":
			countNum = window.prompt( "Enter the quantity of Product 2 sold this week", "0" );
			count = parseInt( countNum );
			total2 = total2 + ( 4.50 * count );
			totalAmount = totalAmount + total2;
			break;
		case "3":
			countNum = window.prompt( "Enter the quantity of Product 3 sold this week", "0" );
			count = parseInt( countNum );
			total3 = total3 + ( 4.50 * count );
			totalAmount = totalAmount + total3;
			break;
		case "4":
			countNum = window.prompt( "Enter the quantity of Product 4 sold this week", "0" );
			count = parseInt( countNum );
			total4 = total4 + ( 4.50 * count );
			totalAmount = totalAmount + total4;
			break;
		case "5":
			countNum = window.prompt( "Enter the quantity of Product 5 sold this week", "0" );
			count = parseInt( countNum );
			total5 = total5 + ( 6.87 * count )
			totalAmount = totalAmount + total5;
			break;
		default:
			window.alert( "Invalid entry, please try again");
			break;
	} // end switch
	
	productNumber = window.prompt( "Enter the product number, -1 to Quit:", "1" );
	
} // end while

document.writeln( "<p>The total for product 1 sold is: $" + total1.toFixed(2) + "</p>");
document.writeln( "<p>The total for product 2 sold is: $" + total2.toFixed(2) + "</p>");
document.writeln( "<p>The total for product 3 sold is: $" + total3.toFixed(2) + "</p>");
document.writeln( "<p>The total for product 4 sold is: $" + total4.toFixed(2) + "</p>");
document.writeln( "<p>The total for product 5 sold is: $" + total5.toFixed(2) + "</p>");
document.writeln( "<h3>The total for all products sold is: $" + totalAmount.toFixed(2) + "</h3>");

// -->