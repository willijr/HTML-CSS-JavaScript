
     <!--
          for ( var count = 0; count < 10; ++count ) {
               if ( count == 5 )
                    continue; 
          }
          document.writeln( count );
     //-->
